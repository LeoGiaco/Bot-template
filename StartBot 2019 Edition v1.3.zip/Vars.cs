﻿using System;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        /// <summary>
        /// Indicates if the coordinate has been multiplied by 16 already or not.
        /// </summary>
        public enum Action
        {
            /// <summary>
            /// Indicates that the no action is required.
            /// </summary>
            None = 1,
            /// <summary>
            /// Indicates that the position has to be divided by 16.
            /// </summary>
            DivideBy16 = 16
        }

        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern bool ReleaseCapture();

        private void Form1_Load(object sender, EventArgs e)
        {
            Email.Text = "";
            WorldId.Text = "";
        }

        private void HiddenPwButton_Click(object sender, EventArgs e)
        {
            bool hidden = Password.UseSystemPasswordChar;
            if (hidden)
            {
                Password.UseSystemPasswordChar = false;
                HiddenPwButton.Text = "Hide";
            }
            else
            {
                Password.UseSystemPasswordChar = true;
                HiddenPwButton.Text = "Show";
            }
        }

        private void Password_TextChanged(object sender, EventArgs e)
        {
            Password.UseSystemPasswordChar = true;
            HiddenPwButton.Text = "Show";
        }

        private void CloseButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }
    }
}
