﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PlayerIOClient;
using System.Timers;
using $safeprojectname$;
using Yonom.EE;

namespace $safeprojectname$.Classes
{
    public static class Room
    {
        public static Connection Con;
        public static Client Client;

        public static BlockController Blocks;
        public static Dictionary<int, Player> Users = new Dictionary<int, Player>();
        public static Queue<Command> Commands = new Queue<Command>();
        public static Timer CmdTimer = new Timer(5);

        public static bool IsConnected = false;
        public static bool IsInitCompleted = false;

        public static string BotName = "[]: ";

        public static char[]Prefixes = { '!', '.' };
        public static int Width, Height;

        /// <summary>
        /// Sends a public message.
        /// </summary>
        /// <param name="format"> String with format. </param>
        /// <param name="args"> Arguments. </param>
        public static void Say(string format, params object[] args) => Con.Send("say", string.Format(format, args));

        /// <summary>
        /// Sends a public message.
        /// </summary>
        /// <param name="msg"> Message. </param>
        public static void Say(string msg) => Con.Send("say", msg);

        /// <summary>
        /// Sends a public message.
        /// </summary>
        /// <param name="obj"> Object whose ToString method is to be called. </param>
        public static void Say(object obj) => Con.Send("say", obj.ToString());

        /// <summary>
        /// Sends a private message.
        /// </summary>
        /// <param name="player"> The receiver. </param>
        /// <param name="format"> String with format. </param>
        /// <param name="args"> Arguments. </param>
        public static void SayPrivate(string player, string format, params object[] args) => Con.Send("say", "/pm " + player + " " + string.Format(format, args));

        /// <summary>
        /// Sends a private message.
        /// </summary>
        /// <param name="player"> The receiver. </param>
        /// <param name="msg"> Message. </param>
        public static void SayPrivate(string player, string msg) => Con.Send("say", "/pm " + player + " " + msg);

        /// <summary>
        /// Sends a private message
        /// </summary>
        /// <param name="player"> The receiver. </param>
        /// <param name="obj"> Object whose ToString method is to be called. </param>
        public static void SayPrivate(string player, object obj) => Con.Send("say", "/pm " + player + " " + obj.ToString());

        public static void JoinWorld(string email, string password, string worldId)
        {
            Client = PlayerIO.QuickConnect.SimpleConnect("everybody-edits-su9rn58o40itdbnw69plyw", email, password, null);
            Con = Client.Multiplayer.CreateJoinRoom(worldId, "public", true, new Dictionary<string, string>(), new Dictionary<string, string>());

            Con.Send("init");
        }

        /// <summary>
        /// Used to place a block in the world.
        /// </summary>
        /// <param name="layer"> Layer of the block(foreground 0, background 1). </param>
        /// <param name="x"> X of the block. </param>
        /// <param name="y"> Y of the block. </param>
        /// <param name="bid"> Id of the block. </param>
        /// <param name="args"> Arguments of the block. </param>
        public static void PlaceBlock(int layer, int x, int y, Form1.Action format, int bid, int arg1 = -1, int arg2 = -1, int arg3 = -1, string text = "")
        {
            x = (int)Math.Round(x / (double)format);
            y = (int)Math.Round(y / (double)format);

            if (arg1 == -1 && arg2 == -1 && arg3 == -1 && text == "") Con.Send("b", layer, x, y, bid);
            else if (arg2 == -1 && arg3 == -1 && text == "") Con.Send("b", layer, x, y, bid, arg1);
            else if (arg3 == -1 && text == "") Con.Send("b", layer, x, y, bid, arg1, arg2);
            else if (text == "") Con.Send("b", layer, x, y, bid, arg1, arg2, arg3);
            else if (arg1 >= 0 && arg2 == -1 && arg3 == -1 && text != "") Con.Send("b", layer, x, y, bid, text, arg1);
            else if (arg1 == -1 && arg2 == -1 && arg3 == -1 && text != "") Con.Send("b", layer, x, y, bid, text);
            else Con.Send("b", layer, x, y, bid, arg1, arg2, arg3);
        }

        /// <summary>
        /// Used to place a block in the world.
        /// </summary>
        /// <param name="layer"> Layer of the block(foreground 0, background 1). </param>
        /// <param name="x"> X of the block. </param>
        /// <param name="y"> Y of the block. </param>
        /// <param name="bid"> Id of the block. </param>
        /// <param name="args"> Arguments of the block. </param>
        public static void PlaceBlock(int layer, double x, double y, Action format, int bid, int arg1 = -1, int arg2 = -1, int arg3 = -1, string text = "") => PlaceBlock(layer, (int)Math.Round(x), (int)Math.Round(y), format, bid, arg1, arg2, arg3, text);

        /// <summary>
        /// Used to place an npc block.
        /// </summary>
        /// <param name="x">X of the block</param>
        /// <param name="y">Y of the block</param>
        /// <param name="bid">Id of the block</param>
        /// <param name="name"> Name of the npc. </param>
        /// <param name="messages"> Messages displayed by the npc. </param>
        public static void PlaceBlock(int x, int y, Form1.Action format, int bid, string name, params string[] messages)
        {
            x = (int)Math.Round(x / (double)format);
            y = (int)Math.Round(y / (double)format);

            switch (messages.Length)
            {
                case 0:
                    Con.Send("b", 0, x, y, bid, name);
                    break;
                case 1:
                    Con.Send("b", 0, x, y, bid, name, messages[0]);
                    break;
                case 2:
                    Con.Send("b", 0, x, y, bid, name, messages[0], messages[1]);
                    break;
                case 3:
                    Con.Send("b", 0, x, y, bid, name, messages[0], messages[1], messages[2]);
                    break;
            }
        }

        /// <summary>
        /// Used to place an npc block.
        /// </summary>
        /// <param name="x">X of the block</param>
        /// <param name="y">Y of the block</param>
        /// <param name="bid">Id of the block</param>
        /// <param name="name"> Name of the npc. </param>
        /// <param name="messages"> Messages displayed by the npc. </param>
        public static void PlaceBlock(double x, double y, Action format, int bid, string name, params string[] messages) => PlaceBlock((int)Math.Round(x), (int)Math.Round(y), format, bid, name, messages);

        public static void Restart(Message m)
        {
            Users.Clear();
            IsInitCompleted = false;
            Say(BotName + "Reloading...");

            //This is to prevent ArgumentNullException:
            for (int x = 0; x <= Width; x++)
            {
                for (int y = 0; y <= Height; y++)
                {
                    Blocks[0, x, y] = new MainBlock(0);
                    Blocks[1, x, y] = new MainBlock(0);
                }
            }

            //Parsing:
            var chunks = InitParse.Parse(m);
            foreach (var c in chunks)
            {
                foreach (var pos in c.Locations)
                {
                    MainBlock b = null;
                    int bid = (int)c.Type;
                    int a1 = -1; int a2 = -1; int a3 = -1; string t = "";
                    //First it checks if the first argument is a string (signs, labels, worldportals, npcs).
                    //It's an int32 if it's not a string
                    if (c.Args.Length >= 1 && c.Args[0] is string)
                    {
                        // If the second argument is a string, then the block is an npc.
                        if (c.Args[1] is string)
                        {
                            b = new NPCBlock(bid, (string)c.Args[0], (string)c.Args[1], (string)c.Args[2], (string)c.Args[3]);
                        }
                        else
                        {
                            //For labels and signs you have an argument for the color. The worldportal doesn't.
                            if (c.Args.Length >= 2)
                                a1 = Convert.ToInt32(c.Args[1]);
                            t = Convert.ToString(c.Args[0]);
                        }
                    }
                    else
                    {
                        if (c.Args.Length >= 1)
                            a1 = Convert.ToInt32(c.Args[0]);
                        if (c.Args.Length >= 2)
                            a1 = Convert.ToInt32(c.Args[1]);
                        if (c.Args.Length >= 3)
                            a1 = Convert.ToInt32(c.Args[2]);
                    }
                    if (b == null)
                        b = new SpecialBlock(bid, a1, a2, a3, t);
                    Blocks[c.Layer, pos.X, pos.Y] = b;
                }
            }

            IsInitCompleted = true;
            Con.Send("init2");
        }
    }
}
