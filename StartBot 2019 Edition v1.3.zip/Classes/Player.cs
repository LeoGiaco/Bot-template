﻿using System.Threading;
using $safeprojectname$.Classes;

namespace $safeprojectname$
{
    public class Player
    {
        public delegate void MessageHandler(Command c);

        public MessageHandler OnMessage;

        public string Username { get; }
        public int Id { get; }
        public double X { get; set; }
        public double Y { get; set; }
        public int DirX { get; set; }
        public int DirY { get; set; }

        public Player(string name, int id, int x, int y)
        {
            Username = name;
            Id = id;
            X = x;
            Y = y;
        }

        /// <summary>
        /// Sends a private message to the player who sent the command.
        /// </summary>
        /// <param name="message"> The message. </param>
        public void Tell(string message) => Room.SayPrivate(Username, message);

        /// <summary>
        /// Sends a private message to the player who sent the command.
        /// </summary>
        /// <param name="format"> The formatted message. </param>
        /// <param name="args"> The arguments. </param>
        public void Tell(string format, params object[] args) => Room.SayPrivate(Username, format, args);

        public Player Find(string username)
        {
            foreach (Player p in Room.Users.Values)
                if (p.Username == username)
                    return p;
            return null;
        }

        public static void DefaultMessageHandler(Command c)
        {
            // Write commands all players can use.
        }

        public static void AdminMessageHandler(Command c)
        {
            // Write commands admins can use.
            //
            //else
            //{
            //    DefaultMessageHandler(c);
            //}
        }
    }
}
