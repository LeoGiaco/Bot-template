﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;

namespace $safeprojectname$
{
    public class BlockController : IEnumerable<MainBlock>
    {
        public MainBlock this[int l, int x, int y]
        {
            get => Matrix[l, x, y];
            set
            {
                Matrix[l, x, y] = value;
            }
        }

        public MainBlock[,,] Matrix { get; } = new MainBlock[2, 637, 401];

        public int Length => Matrix.Length;

        public int GetLength(int dimension) => Matrix.GetLength(dimension);

        public IEnumerator<MainBlock> GetEnumerator()
        {
            for (int l = 0; l < 2; l++)
                for (int x = 0; x < Matrix.GetLength(1); x++)
                    for (int y = 0; y < Matrix.GetLength(2); y++)
                        yield return Matrix[l, x, y];
        }

        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();

        IEnumerable<MainBlock> GetLayer(uint layer)
        {
            if (layer > 1)
                throw new Exception("Layer must be 0 or 1");

            for (int x = 0; x < Matrix.GetLength(1); x++)
                for (int y = 0; y < Matrix.GetLength(2); y++)
                    yield return Matrix[layer, x, y];
        }

        IEnumerable<MainBlock> GetRow(uint layer, uint x)
        {
            for (int y = 0; y < Matrix.GetLength(2); y++)
                yield return Matrix[layer, x, y];
        }

        IEnumerable<MainBlock> GetColumn(uint layer, uint y)
        {
            for (int x = 0; y < Matrix.GetLength(1); y++)
                yield return Matrix[layer, x, y];
        }
    }

    public class MainBlock
    {
        public int Bid { get; set; }

        public MainBlock() { }

        public MainBlock(int bid)
        {
            Bid = bid;
        }

        private MainBlock GetBlock() => GetBlock<MainBlock>();

        public T GetBlock<T>() => (T)Convert.ChangeType(this, typeof(T));

        public override string ToString() => string.Format("Id: {0}", Bid);
    }

    public class SpecialBlock : MainBlock
    {
        public int[] Args { get; set; } = new int[3];
        public string Text { get; set; }

        public SpecialBlock() : base() { }

        public SpecialBlock(int bid, params int[] args) : base(bid)
        {
            if (args.Length > 3)
                throw new Exception("Cannot pass more than 3 messages.");
            Args = args;
            Text = "";
        }

        public SpecialBlock(int bid, string text) : this(bid, -1, -1, -1, text) { }
        public SpecialBlock(int bid, int arg, string text = "") : this(bid, arg, -1, -1, text) { Text = text; }
        public SpecialBlock(int bid, int arg1, int arg2, string text = "") : this(bid, arg1, arg2, -1, text) { Text = text; }
        public SpecialBlock(int bid, int arg1, int arg2, int arg3, string text = "") : base(bid)
        {
            Args = new int[] { arg1, arg2, arg3 };
            Text = text;
        }

        public override string ToString() => base.ToString() + string.Format(", Args: {0}, Text: {1}", string.Join(", ", Args), Text == null ? "-none-" : Text);
    }

    public class NPCBlock : MainBlock
    {
        public string Name { get; set; }
        public string[] Messages { get; set; } = new string[3];

        public string this[int i]
        {
            get => Messages[i];
            set { Messages[i] = value; }
        }

        public NPCBlock() : base() { }

        public NPCBlock(int bid, string name, params string[] msgs) : base(bid)
        {
            if (msgs.Length > 3)
                throw new Exception("Cannot pass more than 3 messages.");
            Name = name;
            Messages = msgs;
        }

        public override string ToString() => base.ToString() + string.Format(", Name: {0}, Messages: {1}", Name, string.Join(", ", Messages));
    }
}
