﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using PlayerIOClient;               //Needed to connect to the game. 
using System.Threading;             //Pauses the bot for some time (in milliseconds).
using System.IO;                    //Needed if you want to save in/load from external files.
using Yonom.EE;
using $safeprojectname$.Classes;

namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Room.CmdTimer.Elapsed += ExecCommands;
            Room.Blocks = new BlockController();
        }

        private void Connect_Click(object sender, EventArgs e)
        {
            if (!Room.IsConnected)
            {
                try
                {
                    Room.JoinWorld(Email.Text, Password.Text, WorldId.Text);
                    Room.Con.OnMessage += new MessageReceivedEventHandler(Handlemsg);
                    Room.CmdTimer.Start();
                    Room.IsConnected = true;
                    Connect.Text = "Disconnect";
                    Room.Users.Clear();
                }
                catch (Exception oops)
                {
                    Room.CmdTimer.Stop();
                    MessageBox.Show(oops.Message, "Error");
                }
            }
            else
            {
                Room.Say(Room.BotName + "Disconnected");
                Room.Users.Clear();
                Room.CmdTimer.Stop();
                Room.IsConnected = false;
                Room.Con.Disconnect();
                Connect.Text = "Connect";
            }
        }

        private void ExecCommands(object sender, System.Timers.ElapsedEventArgs e)
        {
            if(Room.Commands.Count > 0)
            {
                Room.Commands.Dequeue().Execute();
            }
        }

        public void Handlemsg(object sender, PlayerIOClient.Message m)
        {
            #region init
            if (m.Type == "init")
            {
                Room.IsInitCompleted = false;
                Room.Con.Send("smiley", 64);
                Room.Say(Room.BotName + "Loading...");

                //Get width and height of the world:
                Room.Width = m.GetInt(18) - 1;
                Room.Height = m.GetInt(19) - 1;

                //This is to prevent ArgumentNullException:
                for (int x = 0; x <= Room.Width; x++)
                {
                    for (int y = 0; y <= Room.Height; y++)
                    {
                        Room.Blocks[0, x, y] = new MainBlock(0);
                        Room.Blocks[1, x, y] = new MainBlock(0);
                    }
                }

                //Parsing:
                var chunks = InitParse.Parse(m);
                foreach (var c in chunks)
                {
                    foreach (var pos in c.Locations)
                    {
                        MainBlock b = null;
                        int bid = (int)c.Type;
                        int a1 = -1; int a2 = -1; int a3 = -1; string t = "";
                        //First it checks if the first argument is a string (signs, labels, worldportals, npcs).
                        //It's an int32 if it's not a string
                        if (c.Args.Length >= 1 && c.Args[0] is string)
                        {
                            // If the second argument is a string, then the block is an npc.
                            if (c.Args[1] is string)
                            {
                                b = new NPCBlock(bid, (string)c.Args[0], (string)c.Args[1], (string)c.Args[2], (string)c.Args[3]);
                            }
                            else
                            {
                                //For labels and signs you have an argument for the color. The worldportal doesn't.
                                if (c.Args.Length >= 2)
                                    a1 = Convert.ToInt32(c.Args[1]);
                                t = Convert.ToString(c.Args[0]);
                            }
                        }
                        else
                        {
                            if (c.Args.Length >= 1)
                                a1 = Convert.ToInt32(c.Args[0]);
                            if (c.Args.Length >= 2)
                                a1 = Convert.ToInt32(c.Args[1]);
                            if (c.Args.Length >= 3)
                                a1 = Convert.ToInt32(c.Args[2]);
                        }
                        if (b == null)
                            b = new SpecialBlock(bid, a1, a2, a3, t);
                        Room.Blocks[c.Layer, pos.X, pos.Y] = b;
                    }
                }

                Room.IsInitCompleted = true;
                Room.Con.Send("init2");
            }
            #endregion

            #region init2
            else if (m.Type == "init2")
            {
                Room.Say(Room.BotName + "Connected!");
                Room.IsConnected = true;
                Connect.Text = "Disconnect";
                Connect.Enabled = true;
            }
            #endregion

            #region add
            else if (m.Type == "add")
            {
                int id = m.GetInt(0);
                Player p = new Player(m.GetString(1), id, m.GetInt(10), m.GetInt(11));
                if (p.Username == "leogiaco")
                    p.OnMessage = Player.AdminMessageHandler;
                else
                    p.OnMessage = Player.DefaultMessageHandler;
                Room.Users.Add(id, p);
            }
            #endregion

            #region left
            else if (m.Type == "left")
            {
                int id = m.GetInt(0);
                if (Room.Users.ContainsKey(m.GetInt(0)))
                    Room.Users.Remove(m.GetInt(0));
            }
            #endregion

            #region BlockDectection

            // If it's a normal Block:
            else if (m.Type == "b")
            {
                int layer = m.GetInt(0);
                int x = m.GetInt(1);
                int y = m.GetInt(2);
                int bid = m.GetInt(3);
                int id = m.GetInt(4);
                //Only a Block id
                Room.Blocks[layer, x, y] = new MainBlock(bid);
            }
            // Block with number value:
            else if (m.Type == "bc")
            {
                int x = m.GetInt(0);
                int y = m.GetInt(1);
                int bid = m.GetInt(2);
                int value = m.GetInt(3);
                int id = m.GetInt(4);
                // Block id and number value
                Room.Blocks[0, x, y] = new SpecialBlock(bid, value);
            }
            // Morphable Room.Blocks
            else if (m.Type == "br")
            {
                int x = m.GetInt(0);
                int y = m.GetInt(1);
                int bid = m.GetInt(2);
                int variation = m.GetInt(3);
                //m.GetInt(4) is always 0 (layer)
                int id = m.GetInt(5);
                // Block id and variation id
                Room.Blocks[0, x, y] = new SpecialBlock(bid, variation);
            }
            // Sound Block (drum, piano)
            else if (m.Type == "bs")
            {
                int x = m.GetInt(0);
                int y = m.GetInt(1);
                int bid = m.GetInt(2);
                int sound = m.GetInt(3);
                int id = m.GetInt(4);
                // Block id and sound id
                Room.Blocks[0, x, y] = new SpecialBlock(bid, sound);
            }
            // Label (staff-only)
            else if (m.Type == "lb")
            {
                int x = m.GetInt(0);
                int y = m.GetInt(1);
                int bid = m.GetInt(2);
                string text = m.GetString(3);
                int color = m.GetInt(4);
                int id = m.GetInt(5);
                // Block id, text and color id
                Room.Blocks[0, x, y] = new SpecialBlock(bid, color, text);
            }
            // Portals (invisible or regular)
            else if (m.Type == "pt")
            {
                int x = m.GetInt(0);
                int y = m.GetInt(1);
                int bid = m.GetInt(2);
                int rot = m.GetInt(3);
                int portalId = m.GetInt(4);
                int portalTarget = m.GetInt(5);
                int id = m.GetInt(6);
                // Block id, rotation id, portal id and portal target
                Room.Blocks[0, x, y] = new SpecialBlock(bid, rot, portalId, portalTarget);
            }
            // Signs
            else if (m.Type == "ts")
            {
                int x = m.GetInt(0);
                int y = m.GetInt(1);
                int bid = m.GetInt(2);
                string text = m.GetString(3);
                int color = m.GetInt(4);
                int id = m.GetInt(5);
                // Block id, text and color id
                Room.Blocks[0, x, y] = new SpecialBlock(bid, color, text);
            }
            // World portal
            else if (m.Type == "wp")
            {
                int x = m.GetInt(0);
                int y = m.GetInt(1);
                int bid = m.GetInt(2);
                string roomID = m.GetString(3);
                int id = m.GetInt(4);
                // Block id and the ID of the world
                Room.Blocks[0, x, y] = new SpecialBlock(bid, -1, roomID);
            }
            // NPC
            else if (m.Type == "bn")
            {
                int x = m.GetInt(0);
                int y = m.GetInt(1);
                int bid = m.GetInt(2);
                string npcName = m.GetString(3);
                string[] messages = { m.GetString(4), m.GetString(5), m.GetString(6) };
                // Block id, the npc's name and messages.
                Room.Blocks[0, x, y] = new NPCBlock(bid, npcName, messages);
            }

            #endregion

            #region m
            else if (m.Type == "m")
            {
                int id = m.GetInt(0);
                if (Room.Users.ContainsKey(m.GetInt(0)))
                {
                    Room.Users[id].X = m.GetDouble(1) + m.GetDouble(3);
                    Room.Users[id].Y = m.GetDouble(2) + m.GetDouble(4);
                    Room.Users[id].DirX = m.GetInt(7);
                    Room.Users[id].DirY = m.GetInt(8);
                }
            }
            #endregion

            #region say
            else if (m.Type == "say")
            {
                if (Room.Users.ContainsKey(m.GetInt(0)) && Room.Prefixes.Contains(m.GetString(1)[0]))
                    Room.Commands.Enqueue(new Command(Room.Users[m.GetInt(0)], m.GetString(1).ToLower()));
            }
            #endregion

            #region reset
            else if (m.Type == "reset")
            {
                Room.Restart(m);
            }
            #endregion
        }
    }
}
